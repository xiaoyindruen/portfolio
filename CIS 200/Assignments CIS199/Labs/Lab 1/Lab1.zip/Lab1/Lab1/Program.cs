﻿// Lab 1
// CIS 199-01
// Due: 1/24/2021
// By: R2696

// This program displays student's Grading ID,
// hobbies, favorite book and favorite movie to the console.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    // To run Console app from within Visual Studio
    // Choose Debug, Start Without Debugging(Ctrl-F5)
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Grading ID:     R2696");// This is my grading ID.
            Console.WriteLine("Hobbies:        Baking and doing yoga");//These are my hobbies.
            Console.WriteLine("Favorite Book:  The Little Prince");//This is my favorite book.
            Console.WriteLine("Favorite Movie: Frozen");//This is my favorite movie.
        }
    }
}
